SMODS.Joker{ --Deja Vu Joker
    key = "dejavujoker",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Deja Vu Joker',
        ['text'] = {
            [1] = 'Add a {C:red}Red Seal{} to scored cards'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["potato61_potato61_jokers"] = true },

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
                context.other_card:set_seal("Red", true)
                return {
                    message = "Card Modified!"
                }
        end
    end
}