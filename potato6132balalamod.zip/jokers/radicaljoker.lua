SMODS.Joker{ --Radical Joker
    key = "radicaljoker",
    config = {
        extra = {
            echips = 0.5,
            emult = 0.5
        }
    },
    loc_txt = {
        ['name'] = 'Radical Joker',
        ['text'] = {
            [1] = 'gives {X:blue,C:white}^0.5chips{} and {}{X:red,C:white}^0.5 mult{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 1,
    rarity = "potato61_shit",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["potato61_potato61_jokers"] = true },

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    e_chips = card.ability.extra.echips,
                    extra = {
                        e_mult = card.ability.extra.emult,
                        colour = G.C.DARK_EDITION
                        }
                }
        end
    end
}