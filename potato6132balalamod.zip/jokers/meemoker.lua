SMODS.Joker{ --Mee Moker
    key = "meemoker",
    config = {
        extra = {
            mw_chip = 1
        }
    },
    loc_txt = {
        ['name'] = 'Mee Moker',
        ['text'] = {
            [1] = 'Gains {X:chips,C:white}X0.75chips{} if played hand contains a {C:attention}pair{} of {C:attention}2s{}',
            [2] = '{C:inactive}(Currently {X:chips,C:white}X#1#{}{}{C:inactive}){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 4,
        y = 0
    },
    display_size = {
        w = 71 * 0.7, 
        h = 95 * 0.7
    },
    cost = 4,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["potato61_potato61_jokers"] = true, ["potato61_potato61_wee"] = true },

    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.mw_chip}}
    end,

    calculate = function(self, card, context)
        if context.before and context.cardarea == G.jokers  then
            if (next(context.poker_hands["Pair"]) and (function()
    local rankCount = 0
    for i, c in ipairs(context.scoring_hand) do
        if c:get_id() == 2 then
            rankCount = rankCount + 1
        end
    end
    
    return rankCount >= 2
end)()) then
                return {
                    func = function()
                    card.ability.extra.mw_chip = (card.ability.extra.mw_chip) + 0.75
                    return true
                end,
                    message = "Upgrade!"
                }
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    x_chips = card.ability.extra.mw_chip
                }
        end
    end
}