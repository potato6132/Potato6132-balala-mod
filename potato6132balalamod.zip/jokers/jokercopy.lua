SMODS.Joker{ --Jonkler
    key = "jokercopy",
    config = {
        extra = {
            hypermult_n = 4,
            hypermult_arrows = 4
        }
    },
    loc_txt = {
        ['name'] = 'Jonkler',
        ['text'] = {
            [1] = 'Played cards give {X:red,C:white}^^^^4 mult{} when scored'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 2,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 2,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    soul_pos = {
        x = 3,
        y = 0
    },

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
                return {
                    hypermult = {
    card.ability.extra.hypermult_arrows,
    card.ability.extra.hypermult_n
}
                }
        end
    end
}