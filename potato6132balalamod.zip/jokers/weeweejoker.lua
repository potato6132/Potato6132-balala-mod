SMODS.Joker{ --Wee Wee Joker
    key = "weeweejoker",
    config = {
        extra = {
            WWA_Mult = 0,
            WWX_Mult = 1,
            WWE_Mult = 1
        }
    },
    loc_txt = {
        ['name'] = 'Wee Wee Joker',
        ['text'] = {
            [1] = 'gains {C:red}+ 5 mult{}, {X:mult,C:white}X1 mult{} and {X:red,C:white}^0,2mult{}',
            [2] = 'per trigger if played hand is a {C:attention}high card 2{}',
            [3] = '{C:inactive}(currently {C:red}+#1#{}{}, {X:mult,C:white}X#2#{}, {X:red,C:white}^#3#{}{C:inactive}){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 6,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["potato61_potato61_jokers"] = true, ["potato61_potato61_wee"] = true },

    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.WWA_Mult, card.ability.extra.WWX_Mult, card.ability.extra.WWE_Mult}}
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    mult = card.ability.extra.WWA_Mult,
                    extra = {
                        Xmult = card.ability.extra.WWX_Mult,
                        extra = {
                            e_mult = card.ability.extra.WWE_Mult,
                            colour = G.C.DARK_EDITION
                        }
                        }
                }
        end
        if context.individual and context.cardarea == G.play  then
            if (context.scoring_name == "High Card" and (function()
    local allMatchRank = true
    for i, c in ipairs(context.scoring_hand) do
        if not (c:get_id() == 2) then
            allMatchRank = false
            break
        end
    end
    
    return allMatchRank and #context.scoring_hand > 0
end)()) then
                card.ability.extra.WWA_Mult = (card.ability.extra.WWA_Mult) + 5
                card.ability.extra.WWX_Mult = (card.ability.extra.WWX_Mult) + 1
                card.ability.extra.WWE_Mult = (card.ability.extra.WWE_Mult) + 0.2
            end
        end
    end
}