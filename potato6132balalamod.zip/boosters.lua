SMODS.Booster {
    key = 'creditcardpack',
    loc_txt = {
        name = "Credit Card Pack",
        text = {
            "Choose 1 of 2 Credit Cards"
        },
        group_name = "potato61_boosters"
    },
    config = { extra = 2, choose = 1 },
    cost = 1,
    atlas = "CustomBoosters",
    pos = { x = 0, y = 0 },
    group_key = "potato61_boosters",
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        return {
        key = "j_credit_card",
        set = "Joker",
            area = G.pack_cards,
            skip_materialize = true,
            soulable = true,
            key_append = "potato61_creditcardpack"
        }
    end,
    ease_background_colour = function(self)
        ease_colour(G.C.DYN_UI.MAIN, HEX("d5495e"))
        ease_background_colour({ new_colour = HEX('d5495e'), special_colour = HEX("f1ba5b"), contrast = 2 })
    end,
    particles = function(self)
        -- No particles for joker packs
    end,
}


SMODS.Booster {
    key = 'wee_buffoon_pack_2',
    loc_txt = {
        name = "Wee Buffoon Pack",
        text = {
            "A custom booster pack with unique cards."
        },
        group_name = "potato61_boosters"
    },
    config = { extra = 2, choose = 1 },
    cost = 6,
    atlas = "CustomBoosters",
    pos = { x = 1, y = 0 },
    group_key = "potato61_boosters",
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        local selected_index = pseudorandom('potato61_wee_buffoon_pack_2_card', 1, 2)
        if selected_index == 1 then
            return {
            set = "potato61_potato61_wee",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "potato61_wee_buffoon_pack_2"
            }
        elseif selected_index == 2 then
            return {
            key = "j_wee",
            set = "Joker",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "potato61_wee_buffoon_pack_2"
            }
        end
    end,
    particles = function(self)
        -- No particles for joker packs
    end,
}


SMODS.Booster {
    key = 'wee_buffoon_pack',
    loc_txt = {
        name = "Wee Buffoon Pack",
        text = {
            "A custom booster pack with unique cards."
        },
        group_name = "potato61_boosters"
    },
    config = { extra = 2, choose = 1 },
    cost = 6,
    atlas = "CustomBoosters",
    pos = { x = 2, y = 0 },
    group_key = "potato61_boosters",
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        local selected_index = pseudorandom('potato61_wee_buffoon_pack_card', 1, 2)
        if selected_index == 1 then
            return {
            set = "potato61_potato61_wee",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "potato61_wee_buffoon_pack"
            }
        elseif selected_index == 2 then
            return {
            key = "j_wee",
            set = "Joker",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "potato61_wee_buffoon_pack"
            }
        end
    end,
    particles = function(self)
        -- No particles for joker packs
    end,
}


SMODS.Booster {
    key = 'jumbo_wee_buffoon_pack',
    loc_txt = {
        name = "Jumbo Wee Buffoon Pack",
        text = {
            "A custom booster pack with unique cards."
        },
        group_name = "potato61_boosters"
    },
    config = { extra = 4, choose = 1 },
    cost = 8,
    atlas = "CustomBoosters",
    pos = { x = 3, y = 0 },
    group_key = "potato61_boosters",
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        local selected_index = pseudorandom('potato61_jumbo_wee_buffoon_pack_card', 1, 2)
        if selected_index == 1 then
            return {
            set = "potato61_potato61_wee",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "potato61_jumbo_wee_buffoon_pack"
            }
        elseif selected_index == 2 then
            return {
            key = "j_wee",
            set = "Joker",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "potato61_jumbo_wee_buffoon_pack"
            }
        end
    end,
    particles = function(self)
        -- No particles for joker packs
    end,
}


SMODS.Booster {
    key = 'mega_wee_buffoon_pack',
    loc_txt = {
        name = "Mega Wee Buffoon Pack",
        text = {
            "A custom booster pack with unique cards."
        },
        group_name = "potato61_boosters"
    },
    config = { extra = 4, choose = 2 },
    cost = 10,
    atlas = "CustomBoosters",
    pos = { x = 4, y = 0 },
    group_key = "potato61_boosters",
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        local selected_index = pseudorandom('potato61_mega_wee_buffoon_pack_card', 1, 2)
        if selected_index == 1 then
            return {
            set = "potato61_potato61_wee",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "potato61_mega_wee_buffoon_pack"
            }
        elseif selected_index == 2 then
            return {
            key = "j_wee",
            set = "Joker",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "potato61_mega_wee_buffoon_pack"
            }
        end
    end,
    particles = function(self)
        -- No particles for joker packs
    end,
}
