SMODS.Booster {
    key = 'creditcardpack',
    loc_txt = {
        name = "Credit Card Pack",
        text = {
            "Choose 1 of 2 Credit Cards"
        },
        group_name = "potato61_boosters"
    },
    config = { extra = 2, choose = 1 },
    cost = 1,
    atlas = "CustomBoosters",
    pos = { x = 0, y = 0 },
    group_key = "potato61_boosters",
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        return {
        key = "j_credit_card",
        set = "Joker",
            area = G.pack_cards,
            skip_materialize = true,
            soulable = true,
            key_append = "potato61_creditcardpack"
        }
    end,
    ease_background_colour = function(self)
        ease_colour(G.C.DYN_UI.MAIN, HEX("d5495e"))
        ease_background_colour({ new_colour = HEX('d5495e'), special_colour = HEX("f1ba5b"), contrast = 2 })
    end,
    particles = function(self)
        -- No particles for joker packs
    end,
}
