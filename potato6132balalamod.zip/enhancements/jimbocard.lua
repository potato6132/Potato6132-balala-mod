SMODS.Enhancement {
    key = 'jimbocard',
    pos = { x = 0, y = 0 },
    config = {
        extra = {
            odds = 4
        }
    },
    loc_txt = {
        name = 'Jimbo Card',
        text = {
        [1] = '{C:green}1 in 4{} chance to create a {C:dark_edition}negative {}{C:attention}Joker{} when scored'
    }
    },
    atlas = 'CustomEnhancements',
    any_suit = false,
    replace_base_card = false,
    no_rank = false,
    no_suit = false,
    always_scores = false,
    unlocked = true,
    discovered = true,
    no_collection = false,
    weight = 5,
    calculate = function(self, card, context)
        if context.main_scoring and context.cardarea == G.play then
            if SMODS.pseudorandom_probability(card, 'group_0_eda2dc79', 1, card.ability.extra.odds, 'm_potato61_jimbocard') then
                local created_joker = true
                G.E_MANAGER:add_event(Event({
                    func = function()
                        local joker_card = SMODS.add_card({ set = 'Joker', key = 'j_joker' })
                        if joker_card then
                            joker_card:set_edition("e_negative", true)
                            
                        end
                        
                        return true
                    end
                }))
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = created_joker and localize('k_plus_joker') or nil, colour = G.C.BLUE})
            end
        end
    end
}