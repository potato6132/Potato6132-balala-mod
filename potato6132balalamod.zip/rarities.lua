SMODS.Rarity {
    key = "shit",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0.05,
    badge_colour = HEX('70453a'),
    loc_txt = {
        name = "Shit"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}